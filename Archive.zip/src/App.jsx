import React from "react";
import RouterPage from "./RouterPage";

function App() {
  return <RouterPage />;
}

export default App;
